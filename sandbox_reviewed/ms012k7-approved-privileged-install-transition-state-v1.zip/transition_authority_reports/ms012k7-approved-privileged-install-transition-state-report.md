# MS-012K.7 Approved Privileged Install Transition State Report

Verdict: `APPROVED_FOR_EXPLICIT_BUNDLE_INSTALL`

State added:

```text
approved_privileged_install_candidate
```

Required install path:

```text
workflow_dispatch explicit bundle
```
