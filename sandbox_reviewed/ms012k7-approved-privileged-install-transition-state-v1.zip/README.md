# MS-012K.7 Approved Privileged Install Transition State v1

This bundle implements the missing transition state:

```text
approved_privileged_install_candidate
```

It changes `tools/bundle_ingest.py`, so ordinary queue mode should not install it.

## Upload target

```text
incoming/ms012k7-approved-privileged-install-transition-state-v1.zip
```

After sandbox review places it in `sandbox_reviewed/`, run explicit ingest from that stable path with `apply: true`.
