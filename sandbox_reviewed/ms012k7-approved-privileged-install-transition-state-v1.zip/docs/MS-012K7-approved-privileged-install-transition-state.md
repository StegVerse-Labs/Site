# MS-012K.7 Approved Privileged Install Transition State

## Purpose

MS-012K.7 fixes the missing transition state that caused an approved privileged engine mutation to be quarantined as stale debris.

This is not a new guardrail and not a bypass.

## State added

```text
approved_privileged_install_candidate
```

## Transition

```text
already_failed
+ sandbox HOLD
+ human approval receipt
+ explicit bundle mode
+ no workflow file mutation
→ approved_privileged_install_candidate
→ explicit install allowed once
→ consumed approval receipt
→ terminal success or terminal rejection
```

## Existing enforcement stack remains active

```text
BCAT/GCAT
CGE fingerprinting
ingestion rules
sandbox review
transition elements
GitHub enforcement
receipts
```

## What this does not do

```text
No workflow edits.
No queue-mode engine mutation.
No broad tools/ exception.
No arbitrary privileged retry.
No bypass of ingestion/sandbox/receipts.
```
