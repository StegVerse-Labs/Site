# MS-012K.6 Human Approval Receipt

Decision: `APPROVED_FOR_EXPLICIT_BUNDLE_INSTALL`

## Approved subject

```text
tools/bundle_ingest.py
```

Original held bundle:

```text
ms012k6-manifest-post-install-task-bridge-v1.zip
```

Sandbox evidence:

```text
sandbox_reports/ms012k6-manifest-post-install-task-bridge-v1.sandbox-report.json
```

Review packet:

```text
privileged_queue/ms012k6-ingestion-engine-update-review-packet.json
```

## Approved behavior

```text
bundle-manifest.json
→ post_install_tasks
→ task path validation
→ tools/headless_cmd_runner.py
→ data/headless-task-policy-v1.json
→ receipt records post-install execution
```

## Explicit limits

```text
No workflow files.
No cron.
No workflow_run.
No arbitrary task glob execution.
No privileged task bypass.
No post-install execution for sandbox/failed/privileged routes.
```

## Required install method

Use the existing manual explicit-bundle path:

```text
Actions → Ingest Bundle → Run workflow
bundle: incoming/ms012k6-approved-ingestion-engine-replacement-v1.zip
apply: true
```

Do not rely on ordinary queue mode for this bundle. Queue mode correctly blocks ingestion-engine mutation.
