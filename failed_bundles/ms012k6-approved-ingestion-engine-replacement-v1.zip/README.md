# MS-012K.6 Approved Ingestion Engine Replacement v1

This bundle contains an approved replacement for `tools/bundle_ingest.py`.

It must be installed using the existing manual explicit-bundle path:

```text
Actions → Ingest Bundle → Run workflow
bundle: incoming/ms012k6-approved-ingestion-engine-replacement-v1.zip
apply: true
```

Do not rely on queue mode for this bundle.
