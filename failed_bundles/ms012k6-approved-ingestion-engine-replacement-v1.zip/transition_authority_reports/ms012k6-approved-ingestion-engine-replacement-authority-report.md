# MS-012K.6 Approved Ingestion Engine Replacement Authority Report

Verdict: `APPROVED_FOR_EXPLICIT_BUNDLE_INSTALL`

Install path:

```text
workflow_dispatch explicit bundle input
```

Bundle input:

```text
incoming/ms012k6-approved-ingestion-engine-replacement-v1.zip
```

Expected queue-mode result:

```text
SANDBOX_REQUIRED
```

Expected explicit-bundle result:

```text
ALLOW
```
