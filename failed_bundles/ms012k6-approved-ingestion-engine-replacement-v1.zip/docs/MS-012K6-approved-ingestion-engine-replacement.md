# MS-012K.6 Approved Ingestion Engine Replacement

This bundle contains the full reviewed replacement for:

```text
tools/bundle_ingest.py
```

It must be installed with the existing manual explicit-bundle ingestion path.

## Install

```text
Actions → Ingest Bundle → Run workflow
bundle: incoming/ms012k6-approved-ingestion-engine-replacement-v1.zip
apply: true
```

## Why explicit bundle mode is required

Queue mode intentionally blocks ingestion-engine mutation. That guard is correct.

The existing workflow has an explicit bundle input for controlled manual ingestion-engine updates.
