# MS-012E Strict Ingestion Thresholds v1

Upload-safe bundle. No leading-dot paths are included. No workflow files are included.

## Files

| File | Version | Purpose |
|---|---:|---|
| `data/capability-threshold-gates-v1.json` | v1 | Defines stop-gap capability thresholds A-J. |
| `data/transition-capability-scopes-v1.json` | v1 | Defines what current transition/milestone capabilities authorize and do not authorize. |
| `data/stop-gap-policy-v1.json` | v1 | Defines hard stop rules for workflow mutation, authority material, unknown dependency classes, and self-modification. |
| `data/dependency-map-v1.json` | v1 | Maps changed files to impact classes and required checks. |
| `data/bundle-ingestion-policy-v1.json` | v4 | Strict queue ingestion policy with artifact routing, failure quarantine, sandbox routing, and privileged routing. |
| `tools/capability_gate_check.py` | v1 | Classifies bundles and returns `ALLOW`, `SANDBOX_REQUIRED`, `HUMAN_REVIEW_REQUIRED`, `PRIVILEGED_EXECUTOR_REQUIRED`, or `FAIL_CLOSED`. |
| `tools/dependency_impact_scan.py` | v1 | Scans bundle files against dependency map and emits dependency impact reports. |
| `tools/sandbox_bundle_review.py` | v1 | Reviews failed/sandbox bundles for manifest, workflow, unsafe path, and report artifact shape. |
| `tools/bundle_ingest.py` | v4 | Queue-capable strict ingestion engine with quarantine/routing and receipts. |
| `failed_bundles/README.md` | v1 | Documents failure quarantine. |
| `privileged_queue/README.md` | v1 | Documents privileged workflow/authority queue. |
| `sandbox_queue/README.md` | v1 | Documents sandbox repair queue. |
| `dependency_reports/README.md` | v1 | Documents dependency reports. |
| `sandbox_reports/README.md` | v1 | Documents sandbox reports. |
| `bundle-manifest.json` | v1 | Declares bundle contents and safety scope. |

## What this creates

This is the stop-gap threshold and strict ingestion layer.

It makes ingestion ask:

```text
Is this proposed repo transition admissible under the currently available transition capabilities?
```

rather than:

```text
Can I technically write these files?
```

## New ingestion outcomes

```text
ALLOW
SANDBOX_REQUIRED
HUMAN_REVIEW_REQUIRED
PRIVILEGED_EXECUTOR_REQUIRED
FAIL_CLOSED
SKIPPED_ALREADY_SEEN
```

## Queue behavior

The upgraded ingestor supports:

```text
--process-queue
```

That scans `incoming/*.zip` in deterministic name order and continues after failures.

Failed or special bundles route to:

```text
failed_bundles/
privileged_queue/
sandbox_queue/
```

## Important

This bundle does not include workflow changes.

To use queue mode automatically later, the stable ingestion workflow can eventually call:

```text
python tools/bundle_ingest.py --repo-root . --policy data/bundle-ingestion-policy-v1.json --out-dir ingestion_reports --process-queue --apply
```

For now, ingest this bundle explicitly.

## Ingest target

Upload this ZIP to:

```text
incoming/ms012e-strict-ingestion-thresholds-v1.zip
```

Then run `Ingest Bundle` with:

```text
bundle: incoming/ms012e-strict-ingestion-thresholds-v1.zip
apply: true
```

## Done check

After ingestion, the repo should contain the threshold/gate files and the upgraded ingestion engine.

Then the next test is:

```text
1. Ingest a root-level page-contract report artifact ZIP.
2. Confirm it routes to page_contract_reports/.
3. Ingest a root-level transition-replay report artifact ZIP.
4. Confirm it routes to transition_replay_reports/.
5. Run Select Next Transition Step.
```
