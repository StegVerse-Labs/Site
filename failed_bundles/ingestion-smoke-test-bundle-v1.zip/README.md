# Ingestion Smoke Test Bundle v1

This is a harmless test bundle for the MS-012C ingestion receipt boundary.

## Files

```text
bundle-manifest.json
data/ingestion-smoke-test-v1.json
```

## Expected ingestion behavior

```text
data/ingestion-smoke-test-v1.json is created or updated.
A bundle ingestion receipt is written.
The ingestion ledger receives one appended JSONL row.
The fingerprint index records the bundle.
No milestone, transition evidence, replay, selector, or workflow file is changed.
```

## Upload target

Commit this ZIP file under:

```text
incoming/ingestion-smoke-test-bundle-v1.zip
```

Then the `Ingest Bundle` workflow should run automatically.
