# MS-012K.6B Transition Automation Post-Install Trigger v1

Upload after MS-012K.6 is active.

```text
incoming/ms012k6b-transition-automation-post-install-trigger-v1.zip
```
