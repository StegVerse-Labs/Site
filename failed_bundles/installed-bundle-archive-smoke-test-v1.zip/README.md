# Installed Bundle Archive Smoke Test v1

Upload-safe bundle. No leading-dot paths are included. No workflow files are included.

## Files

```text
data/installed-bundle-archive-smoke-test-v1.json
bundle-manifest.json
README.md
```

## Purpose

Verify that a successful ordinary bundle ingestion is archived under:

```text
installed_bundles/
```

Expected installed archive files:

```text
installed_bundles/installed-bundle-archive-smoke-test-v1.zip
installed_bundles/installed-bundle-archive-smoke-test-v1.installed.json
installed_bundles/installed-bundle-archive-smoke-test-v1.installed.md
```

## Ingest target

Upload this ZIP to:

```text
incoming/installed-bundle-archive-smoke-test-v1.zip
```

Run `Ingest Bundle` with:

```text
bundle: incoming/installed-bundle-archive-smoke-test-v1.zip
apply: true
```

## Done check

The ingestion report summary should include:

```text
installed_archived: 1
```
