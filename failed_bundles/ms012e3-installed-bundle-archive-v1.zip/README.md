# MS-012E.3 Installed Bundle Archive v1

Upload-safe bundle. No leading-dot paths are included. No workflow files are included.

## Files

| File | Version | Purpose |
|---|---:|---|
| `tools/bundle_ingest.py` | v7 | Archives successful ALLOW ingestions into `installed_bundles/`. |
| `data/bundle-ingestion-policy-v1.json` | v7 | Adds installed bundle archive policy. |
| `installed_bundles/README.md` | v1 | Documents installed bundle archive. |
| `bundle-manifest.json` | v1 | Declares this bundle. |

## What this adds

Successful installed bundles now archive to:

```text
installed_bundles/
```

with receipts:

```text
installed_bundles/<bundle>.installed.json
installed_bundles/<bundle>.installed.md
```

## Queue meaning

```text
incoming/ = proposed transition intake
installed_bundles/ = accepted/applied transition archive
failed_bundles/ = rejected/stale/failed transition archive
sandbox_queue/ = needs repair/review
privileged_queue/ = needs higher authority
```

## Important

This does not delete originals from `incoming/` by default.

```json
"delete_original_after_install_archive": false
```

## Ingest target

Upload this ZIP to:

```text
incoming/ms012e3-installed-bundle-archive-v1.zip
```

Run `Ingest Bundle` with:

```text
bundle: incoming/ms012e3-installed-bundle-archive-v1.zip
apply: true
```

## Verification

After install, ingest a new ordinary bundle.

Expected report summary includes:

```text
installed_archived: 1
```

and `installed_bundles/` contains the ZIP plus installed receipts.
