# MS-012E.2 Already-Seen Incoming Quarantine Fix v1

Upload-safe bundle. No leading-dot paths are included. No workflow files are included.

## Files

| File | Version | Purpose |
|---|---:|---|
| `tools/bundle_ingest.py` | v6 | Routes already-seen incoming ZIPs to `failed_bundles/` as stale queue debris. |
| `data/bundle-ingestion-policy-v1.json` | v6 | Adds explicit `quarantine_already_seen_incoming` policy. |
| `bundle-manifest.json` | v1 | Declares this bundle. |

## What this fixes

Before this fix, an already-seen bundle under `incoming/` could return:

```text
SKIPPED_ALREADY_SEEN
route: skipped
```

That left old bundles sitting in `incoming/`.

After this fix, an already-seen bundle under `incoming/` returns:

```text
STALE_INCOMING_QUARANTINED
route: failed_bundles
```

and writes:

```text
failed_bundles/<bundle>.stale.json
failed_bundles/<bundle>.stale.md
```

## Important

This still does not delete originals by default.

```json
"delete_original_after_quarantine": false
```

So stale files are copied to quarantine with receipts, not silently removed.

## Ingest target

Upload this ZIP to:

```text
incoming/ms012e2-already-seen-incoming-quarantine-fix-v1.zip
```

Run `Ingest Bundle` with:

```text
bundle: incoming/ms012e2-already-seen-incoming-quarantine-fix-v1.zip
apply: true
```

## Verification

After install, run the same already-seen old bundle again.

Expected report:

```text
verdict: STALE_INCOMING_QUARANTINED
route: failed_bundles
stale_quarantined: 1
```
