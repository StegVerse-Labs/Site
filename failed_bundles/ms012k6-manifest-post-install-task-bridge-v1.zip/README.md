# MS-012K.6 Manifest Post-Install Task Bridge v1

Upload-safe bundle. No workflow files.

This bundle changes `tools/bundle_ingest.py`, so it is an ingestion-engine mutation.

## Ingest target

```text
incoming/ms012k6-manifest-post-install-task-bridge-v1.zip
```
