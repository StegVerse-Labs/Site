# MS-012K.6 Manifest Post-Install Task Bridge

## Purpose

This updates ingestion so `bundle-manifest.json` can declare bounded post-install tasks.

## Mechanism

```text
bundle-manifest.json
→ post_install_tasks
→ tools/bundle_ingest.py validates task paths
→ tools/headless_cmd_runner.py executes declared tasks
→ ingestion receipt records post-install execution
```

## Manifest shape

```json
{
  "post_install_tasks": [
    "data/headless-tasks/transition-automation-controller-v1.json"
  ]
}
```

## Bounds

```text
Only runs after ordinary ALLOW ingest.
Only accepts task paths under data/headless-tasks/.
Only accepts .json task files.
Uses data/headless-task-policy-v1.json.
Uses tools/headless_cmd_runner.py.
Workflow bundles still route to privileged_queue/.
Ingestion-engine mutation bundles still route to sandbox_queue/ in queue mode.
```

## Safety

```text
No workflow files.
No workflow_run.
No cron.
No arbitrary task glob execution.
No direct privileged execution.
```
