# MS-012K.1 Site Path Category Authority Extension v1

Upload-safe bundle. No leading-dot paths are included. No workflow files are included.

## Purpose

Extend the live transition authority map with explicit Site path categories.

## Included

```text
data/transition-table/transition-element-action-authority-map-v1.json
tools/site_path_category_authority_audit.py
data/headless-tasks/site-path-category-authority-audit-v1.json
docs/MS-012K1-site-path-category-authority-extension.md
transition_authority_reports/README.md
bundle-manifest.json
README.md
```

## Added path categories include

```text
scripts
snippets
repo_root
public_pages
public_assets
tools
authority_data
ordinary_data
docs
legacy
workflow_plane
```

## Ingest target

```text
incoming/ms012k1-site-path-category-authority-extension-v1.zip
```
