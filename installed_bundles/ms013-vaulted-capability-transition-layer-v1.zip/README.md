# MS-013 Vaulted Capability Transition Layer v1

Upload-safe bundle. No workflow files. No secrets. No real token issuance.

## Ingest target

```text
incoming/ms013-vaulted-capability-transition-layer-v1.zip
```

## Purpose

Define the first point where TV/TVC becomes a consequence of the transition table: vaulted capability request evaluation and receipt generation.
