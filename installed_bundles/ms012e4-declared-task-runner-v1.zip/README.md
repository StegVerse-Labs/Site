# MS-012E.4 Declared Task Runner v1

Upload-safe bundle. No leading-dot paths are included. No workflow files are included.

## Purpose

This installs the general pattern we discussed:

```text
Workflow YAML = stable dispatcher
Headless command runner = execution surface
Task JSON = mutable operational logic
Tools/data/scripts = implementation layer
Reports/receipts = evidence
```

## Files

```text
tools/headless_cmd_runner.py
data/headless-task-policy-v1.json
data/headless-task-registry-v1.json
data/headless-tasks/ingest-queue-cleanup-v1.json
data/headless-tasks/dependency-impact-scan-v1.json
data/headless-tasks/sandbox-bundle-review-v1.json
headless_cmd_reports/README.md
bundle-manifest.json
README.md
```

## Declared task examples

Queue cleanup:

```text
python tools/headless_cmd_runner.py --task data/headless-tasks/ingest-queue-cleanup-v1.json
```

Dependency impact scan with argument override:

```text
python tools/headless_cmd_runner.py \
  --task data/headless-tasks/dependency-impact-scan-v1.json \
  --arg bundle=incoming/example.zip
```

Sandbox review with argument override:

```text
python tools/headless_cmd_runner.py \
  --task data/headless-tasks/sandbox-bundle-review-v1.json \
  --arg bundle=failed_bundles/example.zip
```

## Ingest target

Upload this ZIP to:

```text
incoming/ms012e4-declared-task-runner-v1.zip
```

Run `Ingest Bundle` with:

```text
bundle: incoming/ms012e4-declared-task-runner-v1.zip
apply: true
```

## Done check

After ingestion, the next ordinary successful ingestion should archive this bundle under `installed_bundles/`.

Then a later stable workflow can call only:

```text
python tools/headless_cmd_runner.py --task data/headless-tasks/ingest-queue-cleanup-v1.json
```

without hardcoding queue logic into workflow YAML.
