# MS-012L.0 Canonical Shell Dependency Map v1

Data/docs-only bundle.

## Upload target

```text
incoming/ms012l0-canonical-shell-dependency-map-v1.zip
```

This bundle establishes the canonical shell/dependency map and does not modify workflows or tools.
