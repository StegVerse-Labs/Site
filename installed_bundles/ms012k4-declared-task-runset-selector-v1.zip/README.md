# MS-012K.4 Declared Task Runset Selector v1

Upload-safe bundle. No workflow files.

## Ingest target

```text
incoming/ms012k4-declared-task-runset-selector-v1.zip
```
