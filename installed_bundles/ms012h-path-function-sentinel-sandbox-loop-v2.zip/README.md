# MS-012H Path Function Sentinel Sandbox Loop v2

Upload-safe bundle. No leading-dot paths are included. No workflow files are included.

## Purpose

Corrected sentinel lifecycle:

```text
sentinel observes deficiency
→ writes sandbox repair task
→ sandbox tests repair
→ repair bundle passes back through ingestion
→ sentinel returns to idle only after ingestion path compliance is restored
```

## Verdicts

```text
IDLE_READY
SANDBOX_TASK_REQUIRED
FAIL_CLOSED
```

## State locations

```text
idle_sentinels/
triggered_loop/
sandbox_tasks/
path_function_reports/
```

## Important

`triggered_loop/` is bounded state, not recursive workflow execution.

## Files

```text
tools/path_function_sentinel_test.py
data/path-tests/path-function-sentinel-policy-v2.json
data/headless-tasks/path-function-sentinel-sandbox-loop-v2.json
path_function_reports/README.md
sandbox_tasks/README.md
idle_sentinels/README.md
triggered_loop/README.md
docs/MS-012H-path-function-sentinel-sandbox-loop.md
bundle-manifest.json
README.md
```

## Ingest target

Upload this ZIP to:

```text
incoming/ms012h-path-function-sentinel-sandbox-loop-v2.zip
```
