# MS-012L.4 Static Public Canonical Pages v1

HTML/docs-only bundle.

Upload target:

```text
incoming/ms012l4-static-public-canonical-pages-v1.zip
```
