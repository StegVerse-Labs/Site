# MS-012I.1 Site Ingest + Sandbox Workflow Replacement

Display path note: `github/workflows/ingest-bundle.yml` is shown without the leading dot. The actual repo path is `.github/workflows/ingest-bundle.yml`.

## Purpose

Replace the existing Site ingestion workflow so it performs a bounded sequence:

```text
ingestion pass
→ ephemeral sandbox pass
→ one post-sandbox ingestion pass
→ explicit-path commit
```

## Safety

```text
No cron.
No workflow_run.
No workflow-to-workflow trigger.
No new workflow file.
No git add .
```

## Install

Replace the full contents of:

```text
.github/workflows/ingest-bundle.yml
```

with `ingest-bundle.yml`.

## Done

Uploading a ZIP to `incoming/` triggers ingestion, sandbox review, post-sandbox candidate ingestion, and explicit-path receipt commits.
