# MS-012K Transition Discovery Ledger v1

Upload-safe bundle. No leading-dot paths are included. No workflow files are included.

## Purpose

Convert real Site outcomes into transition-table discovery evidence.

## Included

```text
data/transition-table/transition-discovery-policy-v1.json
tools/transition_discovery_ledger.py
data/headless-tasks/transition-discovery-ledger-v1.json
transition_discovery_reports/README.md
docs/MS-012K-transition-discovery-ledger.md
bundle-manifest.json
README.md
```

## Outputs

```text
transition_discovery_reports/transition-discovery-ledger.jsonl
transition_discovery_reports/transition-discovery-ledger.json
transition_discovery_reports/transition-element-candidates.json
transition_discovery_reports/transition-element-candidates.md
transition_discovery_reports/transition-discovery-summary.json
transition_discovery_reports/transition-discovery-summary.md
```

## Ingest target

```text
incoming/ms012k-transition-discovery-ledger-v1.zip
```
