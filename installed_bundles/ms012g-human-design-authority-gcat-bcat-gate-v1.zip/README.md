# MS-012G Human Design Authority + GCAT/BCAT Execution Gate v1

Upload-safe bundle. No leading-dot paths are included. No workflow files are included.

## Purpose

This bundle installs the execution authority layer that should have existed beside ingestion:

```text
Trigger requests evaluation.
GCAT/BCAT evaluates admissibility.
The system proposes bounded transitions.
The human approves design direction at capability thresholds.
Only then does execution occur.
```

## Files

```text
tools/gcat_bcat_execution_gate.py
data/gates/human-design-authority-policy-v1.json
data/gcat-bcat/execution-request-template-v1.json
data/headless-tasks/execution-gate-check-v1.json
execution_gate_reports/README.md
docs/MS-012G-human-design-authority-gcat-bcat-gate.md
bundle-manifest.json
README.md
```

## Human authority rule

```text
implementation_detail: system may execute after GCAT/BCAT ALLOW
design_decision: human approval required
authority_expansion: human approval required
recursive_automation: human approval required
workflow_mutation: human approval required
milestone_promotion: human approval required
```

## Ingest target

Upload this ZIP to:

```text
incoming/ms012g-human-design-authority-gcat-bcat-gate-v1.zip
```

## Example check

```text
python tools/gcat_bcat_execution_gate.py \
  --request data/gcat-bcat/execution-request-template-v1.json \
  --policy data/gates/human-design-authority-policy-v1.json \
  --out-dir execution_gate_reports
```
