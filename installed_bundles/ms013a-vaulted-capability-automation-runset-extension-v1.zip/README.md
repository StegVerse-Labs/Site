# MS-013A Vaulted Capability Automation Runset Extension v1

Upload-safe bundle. No workflow files. No engine mutation. No secrets. No token issuance.

## Ingest target

```text
incoming/ms013a-vaulted-capability-automation-runset-extension-v1.zip
```

## Purpose

Adds the vaulted capability gate to the existing transition automation runset.
