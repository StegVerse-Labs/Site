# MS-012K.5 Transition Automation Controller v1

Upload-safe bundle. No workflow files.

## Ingest target

```text
incoming/ms012k5-transition-automation-controller-v1.zip
```
