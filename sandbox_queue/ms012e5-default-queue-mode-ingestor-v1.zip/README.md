# MS-012E.5 Default Queue Mode Ingestor v1

Upload-safe bundle. No leading-dot paths are included. No workflow files are included.

## Purpose

Fix ingestion now without adding another gate and without editing workflow YAML.

## What changes

When `tools/bundle_ingest.py` is called without `--bundle`, it now performs one bounded queue cleanup pass:

```text
incoming/*.zip
→ installed_bundles/ if successfully installed
→ failed_bundles/ if stale, already seen, malformed, or failed
→ sandbox_queue/ if sandbox review is required
→ privileged_queue/ if workflow/privileged mutation is required
```

The source ZIP is removed from `incoming/` after routing during queue mode.

## Why this should self-complete without manual Actions

The first ingestion run installs this file.

Because `tools/bundle_ingest.py` changes, the existing workflow should run again on the commit if it watches `tools/bundle_ingest.py`.

On that second run, there is no explicit bundle input, so the new ingestor cleans the full queue.

## Files

```text
tools/bundle_ingest.py
bundle-manifest.json
README.md
```

## Ingest target

Upload this ZIP to:

```text
incoming/ms012e5-default-queue-mode-ingestor-v1.zip
```

No workflow replacement is required.
