# MS-012E.1 Stale Incoming Quarantine v1

Upload-safe bundle. No leading-dot paths are included. No workflow files are included.

## Files

| File | Version | Purpose |
|---|---:|---|
| `tools/bundle_ingest.py` | v5 | Adds stale incoming quarantine during queue processing. |
| `data/bundle-ingestion-policy-v1.json` | v5 | Adds stale incoming queue policy. |
| `bundle-manifest.json` | v1 | Declares this bundle. |

## What this adds

The ingestor can now quarantine stale files under `incoming/`.

Stale examples:

```text
non-ZIP files in incoming/
invalid ZIP files
ZIPs already processed by hash
ZIPs already routed to failed_bundles/, sandbox_queue/, or privileged_queue/
```

Stale files are routed to:

```text
failed_bundles/
```

with receipts like:

```text
failed_bundles/<name>.stale.json
failed_bundles/<name>.stale.md
```

## Important

This does not delete originals by default.

The policy field is:

```json
"delete_original_after_quarantine": false
```

So stale files are copied into quarantine with receipts, not silently removed.

## Ingest target

Upload this ZIP to:

```text
incoming/ms012e1-stale-incoming-quarantine-v1.zip
```

Run `Ingest Bundle` with:

```text
bundle: incoming/ms012e1-stale-incoming-quarantine-v1.zip
apply: true
```

## Later queue use

After this is installed, queue mode can scan `incoming/` and quarantine stale files:

```text
python tools/bundle_ingest.py --repo-root . --policy data/bundle-ingestion-policy-v1.json --out-dir ingestion_reports --process-queue --apply
```
