# Q67 fixture specimen — GEN 01

- Generation: GEN 01
- ProjectID: Q67-LOCAL-FIXTURE
- Funding: Builder test compute; no sale or price quoted. Full statement: FUNDING__STATEMENT__01.md.
- Source: Q-67 intake INTAKE-3ad36ae081a11bdc34dd2f3b9f749dcb

## Verification

Run `self_check.py`: it verifies every member against
PACKAGE__MANIFEST__01.json (size + SHA-256) and the conformance checklist
carried from the suite template (funding block, ProjectID, derivation).
Derived from SUITE__TEMPLATE — the derivation is recorded in the manifest.

## Actual instance state

SPECIMEN ONLY — full connected product is not offered today.
LOCATED means evidence locations found; it is not a truth verdict.
Analysis: ANALYSIS__01.json. In-suite proof: CONFORMANCE__PROOF__01.json.
Connection state and exact repair: CONNECTION__01.json.
Rail client is read-only and transfers no value. It reads current offers rather than hardcoding prices.
