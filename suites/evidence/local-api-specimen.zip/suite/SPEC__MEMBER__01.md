# Evidence boundary

Only LOCATED claims enter CLAIMS__01.json. Reachability is not semantic validation.
No automatic funds transfer, wallet custody or sovereign admission is performed.
