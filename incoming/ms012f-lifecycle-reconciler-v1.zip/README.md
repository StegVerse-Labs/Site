# MS-012F Lifecycle Reconciler v1

Upload-safe bundle. No leading-dot paths are included. No workflow files are included.

## Purpose

Determine whether MS-012F is actually installed, partially installed, failed-only, conflicted, or missing.

This fixes the evidence problem:

```text
Files existing is not complete lifecycle proof.
Failed bundle copies are not installation proof.
Installed archive receipts are lifecycle proof.
```

## Files

```text
tools/bundle_lifecycle_reconcile.py
data/lifecycle/bundle-lifecycle-reconciliation-policy-v1.json
data/lifecycle/ms012f-lifecycle-subject-v1.json
data/headless-tasks/bundle-lifecycle-reconcile-v1.json
lifecycle_reports/README.md
docs/MS-012F-lifecycle-reconciler.md
bundle-manifest.json
README.md
```

## Ingest target

Upload this ZIP to:

```text
incoming/ms012f-lifecycle-reconciler-v1.zip
```

## Default check

```text
python tools/bundle_lifecycle_reconcile.py \
  --subject data/lifecycle/ms012f-lifecycle-subject-v1.json \
  --policy data/lifecycle/bundle-lifecycle-reconciliation-policy-v1.json \
  --out-dir lifecycle_reports
```

## Possible statuses

```text
installed_verified
files_present_but_archive_missing
failed_only
partially_installed
missing
conflicted
```
