# MS-012K.6A Transition Automation Manifest Trigger v1

Upload only after MS-012K.6 is installed.

## Ingest target

```text
incoming/ms012k6a-transition-automation-manifest-trigger-v1.zip
```
