# MS-012I Site Ephemeral Sandbox Protocols v1

Upload-safe bundle. No leading-dot paths are included. No workflow files are included.

## Purpose

Close the `sandbox_queue/` dead-end for `StegVerse-Labs/Site`.

## Included

```text
tools/ephemeral_sandbox_runner.py
data/sandbox/ephemeral-sandbox-policy-v1.json
data/headless-tasks/ephemeral-sandbox-run-v1.json
sandbox_reports/README.md
sandbox_queue/README.md
sandbox_reviewed/README.md
incoming/README.md
docs/MS-012I-site-ephemeral-sandbox-protocols.md
bundle-manifest.json
README.md
```

## Lifecycle

```text
sandbox_queue/*.zip
→ ephemeral sandbox
→ sandbox_reports/
→ incoming/*.sandbox-candidate.zip when repairable
→ sandbox_reviewed/ for reviewed originals
→ normal ingestion decides final result
```

## Invariant

```text
Sandbox may construct and test.
Sandbox may not install.
Only ingestion installs.
```

## Ingest target

```text
incoming/ms012i-site-ephemeral-sandbox-protocols-v1.zip
```
