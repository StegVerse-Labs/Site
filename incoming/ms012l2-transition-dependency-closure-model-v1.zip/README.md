# MS-012L.2 Transition Dependency Closure Model v1

Data/docs-only bundle.

## Upload target

```text
incoming/ms012l2-transition-dependency-closure-model-v1.zip
```

This bundle defines dependency closure as the condition by which discovered transitions become executable.
