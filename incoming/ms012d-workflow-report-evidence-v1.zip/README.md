# MS-012D Workflow Report Evidence v1

Upload-safe bundle. No leading-dot paths are included.

## Files

| File | Version | Purpose |
|---|---:|---|
| `github/workflows/page-contract-check.yml` | v2 | Runs Page Contract Check and commits report JSON/Markdown into `page_contract_reports/`. |
| `github/workflows/transition-replay-check.yml` | v2 | Runs Transition Replay Check and commits report JSON/Markdown into `transition_replay_reports/`. |
| `data/workflow-report-evidence-policy-v1.json` | v1 | Defines the repo-readable evidence policy. |
| `page_contract_reports/README.md` | v1 | Documents selector-readable page-contract evidence. |
| `transition_replay_reports/README.md` | v1 | Documents selector-readable replay evidence. |
| `bundle-manifest.json` | v1 | Declares bundle contents and safety scope. |

## Important workflow path note

This bundle intentionally stores workflows without leading dots:

```text
github/workflows/page-contract-check.yml
github/workflows/transition-replay-check.yml
```

When ingested, the ingestion engine maps them to:

```text
.github/workflows/page-contract-check.yml
.github/workflows/transition-replay-check.yml
```

## Why this is needed

`Select Next Transition Step` cannot read GitHub Actions artifacts from previous workflow runs. It can only read files in the checked-out repository workspace.

So the verifier workflows must commit their reports into stable repo-readable directories:

```text
page_contract_reports/page-contract-report.json
transition_replay_reports/transition-replay-report.json
```

## Done check

After this bundle is ingested:

```text
1. Run Actions → Transition Replay Check.
2. Run Actions → Page Contract Check.
3. Confirm both commit their report files.
4. Run Actions → Select Next Transition Step.
```

Expected selector result if both verifier reports pass:

```text
next_system_action = promote_candidate_milestone
promotion_allowed = true
human_required = false
```
