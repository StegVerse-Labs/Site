# transition_replay_reports

Repo-readable evidence directory for `Transition Replay Check`.

The workflow writes:

```text
transition_replay_reports/transition-replay-report.json
transition_replay_reports/transition-replay-report.md
```

The next-step selector reads this JSON to classify `transition_replay_check`.

This directory is evidence storage, not public page content.
