# page_contract_reports

Repo-readable evidence directory for `Page Contract Check`.

The workflow writes:

```text
page_contract_reports/page-contract-report.json
page_contract_reports/page-contract-report.md
```

The next-step selector reads this JSON to classify `page_contract_check`.

This directory is evidence storage, not public page content.
