# MS-012K.3 Declared Headless Task Path Handler

## Purpose

MS-012K.3 gives the transition-table ecosystem a bounded capability execution bridge.

This is not a mobile convenience layer. It is the mechanism that lets table-unlocked discovery tasks run and feed evidence back into the table.

## Architecture

```text
Transition table discovers/unlocks action capability
→ declared task records executable form
→ workflow/path handler detects established task path
→ headless runner validates authority class
→ tool executes bounded task
→ reports/receipts become new discovery evidence
→ table learns from the result
```

## Workflow plane rule

The workflow does not decide what to do.

It only handles the established path:

```text
data/headless-tasks/*.json
```

and calls:

```text
tools/headless_cmd_runner.py
```

## Initial allowlisted declared tasks

```text
data/headless-tasks/transition-authority-audit-v1.json
data/headless-tasks/site-path-category-authority-audit-v1.json
data/headless-tasks/transition-discovery-ledger-v1.json
data/headless-tasks/site-construction-plane-discovery-v1.json
```

## Allowed outputs

```text
headless_cmd_reports/
transition_authority_reports/
transition_discovery_reports/
```

## Still denied

```text
workflow_mutation
secret_mutation
branch_protection_mutation
privileged_executor
authority_expansion
public_release_promotion
branch_deletion
```

## Display path note

`github/workflows/declared-headless-task-handler.yml` is shown without the leading dot in documentation. The actual repo path is `.github/workflows/declared-headless-task-handler.yml`.

## Safety

```text
No cron.
No workflow_run.
No workflow-to-workflow trigger.
No git add .
No arbitrary task glob execution.
Only allowlisted observe/report/discovery task files run.
```
