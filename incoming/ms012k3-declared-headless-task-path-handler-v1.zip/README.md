# MS-012K.3 Declared Headless Task Path Handler v1

This bundle intentionally includes a workflow file.

## Display path note

`github/workflows/declared-headless-task-handler.yml` is shown without the leading dot in documentation. The actual repo path inside this bundle is:

```text
.github/workflows/declared-headless-task-handler.yml
```

## Purpose

Install the bounded path handler that lets transition-table declared observe/report/discovery tasks execute and feed receipts back into discovery.

## Included

```text
.github/workflows/declared-headless-task-handler.yml
data/headless-task-policy-v1.json
docs/MS-012K3-declared-headless-task-path-handler.md
bundle-manifest.json
README.md
```

## Runs only these declared tasks

```text
data/headless-tasks/transition-authority-audit-v1.json
data/headless-tasks/site-path-category-authority-audit-v1.json
data/headless-tasks/transition-discovery-ledger-v1.json
data/headless-tasks/site-construction-plane-discovery-v1.json
```

## Commits only

```text
headless_cmd_reports/
transition_authority_reports/
transition_discovery_reports/
```

## Safety

```text
No cron
No workflow_run
No workflow-to-workflow trigger
No git add .
No arbitrary task glob execution
No privileged execution
No authority expansion
```

## Ingest target

```text
incoming/ms012k3-declared-headless-task-path-handler-v1.zip
```
