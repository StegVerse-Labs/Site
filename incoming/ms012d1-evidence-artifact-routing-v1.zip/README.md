# MS-012D.1 Evidence Artifact Routing v1

Upload-safe bundle. No leading-dot paths are included.

## Files

| File | Version | Purpose |
|---|---:|---|
| `tools/bundle_ingest.py` | v3 | Routes known root-level GitHub artifact report files into selector-readable evidence directories. |
| `data/bundle-ingestion-policy-v1.json` | v3 | Adds artifact file mappings for page contract and transition replay reports. |
| `bundle-manifest.json` | v1 | Declares this bundle and its artifact routes. |

## What this fixes

GitHub report artifact ZIPs may contain files at ZIP root:

```text
page-contract-report.json
page-contract-report.md
transition-replay-report.json
transition-replay-report.md
```

The selector expects:

```text
page_contract_reports/page-contract-report.json
page_contract_reports/page-contract-report.md
transition_replay_reports/transition-replay-report.json
transition_replay_reports/transition-replay-report.md
```

This ingestor upgrade routes those known artifact files automatically.

## Ingest target

Upload this bundle to:

```text
incoming/ms012d1-evidence-artifact-routing-v1.zip
```

Then commit it to `main`.

## Done check

```text
1. Ingest this bundle.
2. Re-ingest the Page Contract Check artifact ZIP.
3. Re-ingest the Transition Replay Check artifact ZIP.
4. Confirm the repo contains:
   page_contract_reports/page-contract-report.json
   transition_replay_reports/transition-replay-report.json
5. Run Actions → Select Next Transition Step.
```

Expected selector result after both reports are present and passing:

```text
next_system_action = promote_candidate_milestone
promotion_allowed = true
human_required = false
```
