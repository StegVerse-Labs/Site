# MS-012F Deprecated-Purpose Sandbox Review v1

Upload-safe bundle. No leading-dot paths are included. No workflow files are included.

## Files

| File | Version | Purpose |
|---|---:|---|
| `data/deprecation-policy-v1.json` | v1 | Defines purpose-status classes and supersession rules. |
| `data/sandbox-review-policy-v1.json` | v1 | Defines sandbox review dimensions and outputs. |
| `tools/sandbox_bundle_review.py` | v2 | Reviews bundle shape and whether purpose is active, deprecated, superseded, obsolete, critical, or unknown. |
| `sandbox_reports/README.md` | v2 | Documents purpose-aware sandbox review. |
| `bundle-manifest.json` | v1 | Declares this bundle. |

## What this adds

When stale or failed bundles are reviewed later, sandbox testing now asks:

```text
Is this bundle purpose still active?
Has it been superseded?
Is it deprecated?
Is it obsolete?
Is it critical historical evidence even if old?
Is the purpose unknown and therefore human-review required?
```

## Ingest target

Upload this ZIP to:

```text
incoming/ms012f-deprecated-purpose-sandbox-review-v1.zip
```

Run `Ingest Bundle` with:

```text
bundle: incoming/ms012f-deprecated-purpose-sandbox-review-v1.zip
apply: true
```

## Example sandbox review

```text
python tools/sandbox_bundle_review.py \
  --bundle failed_bundles/example.zip \
  --deprecation-policy data/deprecation-policy-v1.json \
  --out-dir sandbox_reports
```
