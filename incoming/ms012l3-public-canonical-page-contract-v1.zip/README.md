# MS-012L.3 Public Canonical Page Contract v1

Data/docs-only bundle.

## Upload target

```text
incoming/ms012l3-public-canonical-page-contract-v1.zip
```

This bundle defines how canonical data should surface into public HTML pages.
